#ifndef TESTINGFRAMEWORK_H
#define TESTINGFRAMEWORK_H

#include <iostream>

void testAll();

#endif // TESTINGFRAMEWORK_H
