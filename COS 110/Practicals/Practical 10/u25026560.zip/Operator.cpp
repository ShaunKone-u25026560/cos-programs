template <class T>
Operator<T>::Operator()
{}

template <class T>
Operator<T>::~Operator()
{}