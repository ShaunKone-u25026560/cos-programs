#include "Threat.h"

Threat::Threat(int damage) // Function 1
{
    this->damage = damage;
}

Threat::~Threat() // Function 2
{}
