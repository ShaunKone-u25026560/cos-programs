#ifndef TESTINGFRAMEWORK_H
#define TESTINGFRAMEWORK_H

#include <iostream>
#include <string>
#include "TileException.h"

void testAll();

#endif // TESTINGFRAMEWORK_H
