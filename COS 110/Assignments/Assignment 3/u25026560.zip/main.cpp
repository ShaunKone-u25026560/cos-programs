#include "iostream"
#include "fstream"
#include "sstream"
#include "string"

#include "testingFramework.h"

int main(){

    testAll();
    return 0;
}
