#ifndef BOOLEANELEMENT_H
#define BOOLEANELEMENT_H

#include <string>
#include <iostream>
#include <fstream>
#include <sstream>

#include "Element.h"


#endif /* BOOLEANELEMENT_H */
