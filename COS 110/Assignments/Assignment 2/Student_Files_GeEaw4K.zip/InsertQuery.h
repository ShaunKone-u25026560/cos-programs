#ifndef INSERTQUERY_H
#define INSERTQUERY_H

#include <string>
#include <iostream>
#include <fstream>
#include <sstream>

#include "QueryResponse.h"
#include "Query.h"
#include "Database.h"


#endif /* INSERTQUERY_H */
