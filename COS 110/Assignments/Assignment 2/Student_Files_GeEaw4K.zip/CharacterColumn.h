#ifndef CHARACTERCOLUMN_H
#define CHARACTERCOLUMN_H

#include <string>
#include <iostream>
#include <fstream>
#include <sstream>

#include "Column.h"
#include "CharacterElement.h"


#endif /* CHARACTERCOLUMN_H */
