#ifndef TEXTELEMENT_H
#define TEXTELEMENT_H

#include <string>
#include <iostream>
#include <fstream>
#include <sstream>

#include "Element.h"


#endif /* TEXTELEMENT_H */
