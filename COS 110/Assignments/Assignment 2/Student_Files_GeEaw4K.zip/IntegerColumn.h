#ifndef INTERGERCOLUMN_H
#define INTERGERCOLUMN_H

#include <string>
#include <iostream>
#include <fstream>
#include <sstream>

#include "Column.h"
#include "IntegerElement.h"


#endif /* INTERGERCOLUMN_H */
