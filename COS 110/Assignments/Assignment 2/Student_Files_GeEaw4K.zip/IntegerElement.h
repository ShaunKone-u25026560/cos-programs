#ifndef INTERGERELEMENT_H
#define INTERGERELEMENT_H

#include <sstream>
#include <iostream>
#include <string>
#include <fstream>

#include "Element.h"


#endif /* INTERGERELEMENT_H */
