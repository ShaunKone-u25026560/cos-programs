#ifndef BOOLEANCOLUMN_H
#define BOOLEANCOLUMN_H

#include <string>
#include <iostream>
#include <fstream>
#include <sstream>

#include "TemplateFunctions.h"
#include "Column.h"
#include "BooleanElement.h"



#endif /* BOOLEANCOLUMN_H */
