#ifndef SEARCHQUERY_H
#define SEARCHQUERY_H

#include <string>
#include <iostream>
#include <fstream>
#include <sstream>

#include "QueryResponse.h"
#include "Query.h"
#include "Database.h"


#endif /* SEARCHQUERY_H */
