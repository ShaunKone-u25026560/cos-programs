#ifndef TEXTCOLUMN_H
#define TEXTCOLUMN_H

#include <string>
#include <iostream>
#include <fstream>
#include <sstream>

#include "Column.h"
#include "TextElement.h"


#endif /* TEXTCOLUMN_H */
