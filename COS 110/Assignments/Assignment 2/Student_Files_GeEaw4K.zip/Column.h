#ifndef COLUMN_H
#define COLUMN_H

#include <string>
#include <iostream>
#include <fstream>
#include <sstream>

#include "Element.h"
#include "TemplateFunctions.h"

class Column;
class BooleanColumn;
class CharacterColumn;
class IntegerColumn;
class RealValueColumn;
class TextColumn;

class Column
{

};

#endif /* COLUMN_H */
