#ifndef CHARACTERELEMENT_H
#define CHARACTERELEMENT_H

#include <string>
#include <iostream>
#include <fstream>
#include <sstream>

#include "Element.h"



#endif /* CHARACTERELEMENT_H */
