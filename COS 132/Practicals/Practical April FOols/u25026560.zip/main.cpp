#include <iostream>
#include <string>
#include "QuantumQubitSystem.h"

int main()
{
	Quantum_Compute();

	return 0;
}
