#ifndef Quantum_H
#define Quantun_H

void Quantum_Compute();

#endif
