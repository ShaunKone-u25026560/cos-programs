#include <iostream>
#include <string>
#include "QuantumQubitSystem.h"

using namespace std;

void Quantum_Compute()
{
        std::cout << "https://youtu.be/dQw4w9WgXcQ?si=bcKF5hkJLSQTMxcq" << std::endl;
}
