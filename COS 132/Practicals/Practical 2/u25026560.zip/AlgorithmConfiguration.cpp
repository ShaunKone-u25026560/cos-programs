#include "AlgorithmConfiguration.h"

using namespace std;

int START;
int END;
bool MOVETONEXT;
float AVERAGE;
float VALUE;

void printStart()
{
	cout << "START: " << START << endl;
}

void printEnd()
{
	cout << "END: " << END << endl;
}

void printMoveToNext()
{
	cout << "MOVETONEXT: " << MOVETONEXT << endl;
}

void printAverage()
{
	cout << "AVERAGE: " << AVERAGE << endl;
}

void printValue()
{
	cout << "VALUE: " << VALUE << endl;
}
